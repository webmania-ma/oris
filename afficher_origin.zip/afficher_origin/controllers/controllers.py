# -*- coding: utf-8 -*-
# from odoo import http


# class AfficherOrigin(http.Controller):
#     @http.route('/afficher_origin/afficher_origin/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/afficher_origin/afficher_origin/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('afficher_origin.listing', {
#             'root': '/afficher_origin/afficher_origin',
#             'objects': http.request.env['afficher_origin.afficher_origin'].search([]),
#         })

#     @http.route('/afficher_origin/afficher_origin/objects/<model("afficher_origin.afficher_origin"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('afficher_origin.object', {
#             'object': obj
#         })
