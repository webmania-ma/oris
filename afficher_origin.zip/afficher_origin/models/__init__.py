# -*- coding: utf-8 -*-

from . import add_checkbox
from . import inherit_depenses
