# -*- coding: utf-8 -*-
{
    'name': "LDM V5 Prix de vente et le coût dans BC odoo webmania v14",
    'summary':"""
        Prix de vente et côut et le margin dans bon commandes 
    """,
    'description': """
    L'ajout de champs prix de vente et le coût et le margin sur module  d'achat dans la ligne de commande
    """,
    'author': 'Webmania',
    "website": "https://webmania.ma",
    'category': 'Point of Sale',
    'version': '0.1',
    # any module necessary for this one to work correctly
    'depends': ['base', 'purchase'],
    # always loaded
    'data': [
        #'security/ir.model.access.csv',
        'data/invoke_function.xml',
        'reports/report_bon_commande.xml',
        'reports/report_bon_commande_template.xml',
        'views/purchase_order_line_inherit.xml',
    ],

}
